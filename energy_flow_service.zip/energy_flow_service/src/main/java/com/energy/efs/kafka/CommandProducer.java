package com.energy.efs.kafka;

import com.energy.efs.model.CommandPayload;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class CommandProducer {

    private final KafkaTemplate<String, String> kafkaTemplate;

    public CommandProducer(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendCommand(String batteryId, CommandPayload payload) {
        String message =
                "{ \"batteryId\":\"" + payload.getBatteryId() +
                        "\", \"charge\":" + payload.isCharging() +
                        ", \"source\":\"" + payload.getSource() + "\" }";

        kafkaTemplate.send("battery-command", message);
        System.out.println("COMMAND SENT → " + message);
    }
}
