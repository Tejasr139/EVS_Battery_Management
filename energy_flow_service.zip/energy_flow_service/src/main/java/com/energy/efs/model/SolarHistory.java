package com.energy.efs.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import java.time.LocalDateTime;

@Entity
public class SolarHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String solarId;
    private double generation;
    private String status;
    private LocalDateTime timestamp;

    public SolarHistory() {}

    public SolarHistory(Long id, String solarId, double generation, String status, LocalDateTime timestamp) {
        this.id = id;
        this.solarId = solarId;
        this.generation = generation;
        this.status = status;
        this.timestamp = timestamp;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getSolarId() { return solarId; }
    public void setSolarId(String solarId) { this.solarId = solarId; }

    public double getGeneration() { return generation; }
    public void setGeneration(double generation) { this.generation = generation; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public static SolarHistoryBuilder builder() {
        return new SolarHistoryBuilder();
    }

    public static class SolarHistoryBuilder {
        private Long id;
        private String solarId;
        private double generation;
        private String status;
        private LocalDateTime timestamp;

        public SolarHistoryBuilder id(Long id) { this.id = id; return this; }
        public SolarHistoryBuilder solarId(String solarId) { this.solarId = solarId; return this; }
        public SolarHistoryBuilder generation(double generation) { this.generation = generation; return this; }
        public SolarHistoryBuilder status(String status) { this.status = status; return this; }
        public SolarHistoryBuilder timestamp(LocalDateTime timestamp) { this.timestamp = timestamp; return this; }

        public SolarHistory build() {
            return new SolarHistory(id, solarId, generation, status, timestamp);
        }
    }
}
