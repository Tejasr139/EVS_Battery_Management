package com.energy.efs.repository;

import com.energy.efs.model.SolarHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface SolarHistoryRepository extends JpaRepository<SolarHistory, Long> {
    Optional<SolarHistory> findTopByOrderByTimestampDesc();
}
