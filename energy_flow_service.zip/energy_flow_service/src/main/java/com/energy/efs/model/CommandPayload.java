package com.energy.efs.model;

//DTO

public class CommandPayload {
    private String batteryId;
    private boolean charging;
    private String source;  // SOLAR or GRID

    public CommandPayload() {}

    public CommandPayload(String batteryId, boolean charging, String source) {
        this.batteryId = batteryId;
        this.charging = charging;
        this.source = source;
    }

    public String getBatteryId() { return batteryId; }
    public void setBatteryId(String batteryId) { this.batteryId = batteryId; }

    public boolean isCharging() { return charging; }
    public void setCharging(boolean charging) { this.charging = charging; }

    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }
}
