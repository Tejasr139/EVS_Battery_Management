package com.energy.efs.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import java.time.LocalDateTime;

@Entity
public class BatteryHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String batteryId;
//    private double soc;
//    private double soh;
//    private double temperature;
    private LocalDateTime timestamp;

    private double inflow;
    private double outflow;

    public BatteryHistory() {}

    public BatteryHistory(Long id, String batteryId, LocalDateTime timestamp, double inflow, double outflow) {
        this.id = id;
        this.batteryId = batteryId;
        this.timestamp = timestamp;
        this.inflow = inflow;
        this.outflow = outflow;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getBatteryId() { return batteryId; }
    public void setBatteryId(String batteryId) { this.batteryId = batteryId; }

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public double getInflow() { return inflow; }
    public void setInflow(double inflow) { this.inflow = inflow; }

    public double getOutflow() { return outflow; }
    public void setOutflow(double outflow) { this.outflow = outflow; }

    public static BatteryHistoryBuilder builder() {
        return new BatteryHistoryBuilder();
    }

    public static class BatteryHistoryBuilder {
        private Long id;
        private String batteryId;
        private LocalDateTime timestamp;
        private double inflow;
        private double outflow;

        public BatteryHistoryBuilder id(Long id) { this.id = id; return this; }
        public BatteryHistoryBuilder batteryId(String batteryId) { this.batteryId = batteryId; return this; }
        public BatteryHistoryBuilder timestamp(LocalDateTime timestamp) { this.timestamp = timestamp; return this; }
        public BatteryHistoryBuilder inflow(double inflow) { this.inflow = inflow; return this; }
        public BatteryHistoryBuilder outflow(double outflow) { this.outflow = outflow; return this; }

        public BatteryHistory build() {
            return new BatteryHistory(id, batteryId, timestamp, inflow, outflow);
        }
    }
}
