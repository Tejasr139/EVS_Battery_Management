package com.energy.efs.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import java.time.LocalDateTime;

@Entity
public class GridHistory {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String gridId;
    private double output;
    private LocalDateTime timestamp;

    public GridHistory() {}

    public GridHistory(String gridId, double output, LocalDateTime timestamp) {
        this.gridId = gridId;
        this.output = output;
        this.timestamp = timestamp;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getGridId() { return gridId; }
    public void setGridId(String gridId) { this.gridId = gridId; }

    public double getOutput() {return output;}

    public void setOutput(double output) {this.output = output;}

    public LocalDateTime getTimestamp() { return timestamp; }
    public void setTimestamp(LocalDateTime timestamp) { this.timestamp = timestamp; }

    public static GridHistoryBuilder builder() {
        return new GridHistoryBuilder();
    }

    public static class GridHistoryBuilder {
        private String gridId;
        private double output;
        private LocalDateTime timestamp;

        public GridHistoryBuilder gridId(String gridId) { this.gridId = gridId; return this; }
        public GridHistoryBuilder output(double output) { this.output = output; return this; }
        public GridHistoryBuilder timestamp(LocalDateTime timestamp) { this.timestamp = timestamp; return this; }

        public GridHistory build() {
            return new GridHistory(gridId, output, timestamp);
        }
    }
}
