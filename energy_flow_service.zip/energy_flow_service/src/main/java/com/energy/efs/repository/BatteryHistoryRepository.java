package com.energy.efs.repository;

import com.energy.efs.model.BatteryHistory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BatteryHistoryRepository  extends JpaRepository<BatteryHistory, Long> {
}
