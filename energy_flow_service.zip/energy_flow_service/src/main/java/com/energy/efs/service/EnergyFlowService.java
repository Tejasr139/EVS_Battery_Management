package com.energy.efs.service;


import com.energy.efs.kafka.CommandProducer;
import com.energy.efs.model.BatteryHistory;
import com.energy.efs.model.CommandPayload;
import com.energy.efs.model.GridHistory;
import com.energy.efs.model.SolarHistory;
import com.energy.efs.repository.BatteryHistoryRepository;
import com.energy.efs.repository.GridHistoryRepository;
import com.energy.efs.repository.SolarHistoryRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service
public class EnergyFlowService {

    private final BatteryHistoryRepository batteryRepo;
    private final SolarHistoryRepository solarRepo;
    private final GridHistoryRepository gridRepo;
    private final CommandProducer commandProducer;

    public EnergyFlowService(BatteryHistoryRepository batteryRepo, SolarHistoryRepository solarRepo, GridHistoryRepository gridRepo, CommandProducer commandProducer) {
        this.batteryRepo = batteryRepo;
        this.solarRepo = solarRepo;
        this.gridRepo = gridRepo;
        this.commandProducer = commandProducer;
    }

    // Store last SOC & last command for each battery
    private final Map<String, Double> lastSocMap = new HashMap<>();
    private final Map<String, Boolean> lastChargingMap = new HashMap<>(); // true=charge, false=discharge
    private final Map<String, String> lastSourceMap = new HashMap<>();


    public void processBatteryTelemetry(String batteryId, double soc, double soh, double temperature) {

        int hour = LocalTime.now().getHour();
        boolean isDay = hour >= 6 && hour < 18;
        String source = isDay ? "SOLAR" : "GRID";

        // ---------------- Store inflow/outflow -----------------
        double inflow = 0, outflow = 0;
        Double lastSoc = lastSocMap.get(batteryId);

        if (lastSoc != null) {
            if (soc > lastSoc) inflow = soc - lastSoc;
            else if (soc < lastSoc) outflow = lastSoc - soc;
        }
        lastSocMap.put(batteryId, soc);

        boolean charging;
        String commandSource;

        // ------------ RULE 1: SOC < 40 → MUST CHARGE ----------------
        if (soc < 40) {
            charging = true;
            commandSource = source;

            System.out.println("SOC<40 → Charging using " + commandSource);
        }

        // ------------ RULE 2: SOC > 80 → MUST DISCHARGE -------------
        else if (soc > 80) {
            charging = false;
            commandSource = null;

            System.out.println("SOC>80 → Discharging");
        }

        // ------------ RULE 3: Between 40 and 80 → Follow previous ----
        else {
            if (!lastChargingMap.containsKey(batteryId)) {
                // If first time → default CHARGE
                charging = true;
                commandSource = source;
            } else {
                charging = lastChargingMap.get(batteryId);
                commandSource = lastSourceMap.get(batteryId);
            }

            System.out.println("40 < SOC < 80 → Continuing previous action: " +
                    (charging ? "Charging" : "Discharging"));
        }

        // Save last decision
        lastChargingMap.put(batteryId, charging);
        lastSourceMap.put(batteryId, commandSource);

        // ----------- SEND COMMAND TO SIMULATOR ----------------
        CommandPayload payload = new CommandPayload(batteryId, charging, commandSource);
        commandProducer.sendCommand(batteryId, payload);

        System.out.println("Sent Command → " + payload);

        // ----------- SAVE FLOW HISTORY TO DB ------------------
        BatteryHistory history = BatteryHistory.builder()
                .batteryId(batteryId)
                .timestamp(LocalDateTime.now())
                .inflow(inflow)
                .outflow(outflow)
                .build();

        batteryRepo.save(history);
    }

    public double getTotalEnergyInflow() {
        return batteryRepo.findAll().stream()
                .mapToDouble(BatteryHistory::getInflow)
                .sum();
    }

    public double getTotalEnergyOutflow() {
        return batteryRepo.findAll().stream()
                .mapToDouble(BatteryHistory::getOutflow)
                .sum();
    }
}

