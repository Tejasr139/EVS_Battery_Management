package com.energy.efs.controller;

import com.energy.efs.service.EnergyFlowService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/energy")
public class EnergyFlowController {

    private final EnergyFlowService flowService;

    public EnergyFlowController(EnergyFlowService flowService) {
        this.flowService = flowService;
    }

    @GetMapping("/inflow")
    public double getTotalInflow() {
        return flowService.getTotalEnergyInflow();
    }

    @GetMapping("/outflow")
    public double getTotalOutflow() {
        return flowService.getTotalEnergyOutflow();
    }
}
