package com.energy.efs.kafka;

import com.energy.efs.model.GridHistory;
import com.energy.efs.model.SolarHistory;
//import com.energy.efs.service.EnergyFlowController;
import com.energy.efs.repository.GridHistoryRepository;
import com.energy.efs.repository.SolarHistoryRepository;
import com.energy.efs.service.EnergyFlowService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class TelemetryConsumer {

    private final ObjectMapper objectMapper;
//    private final BatteryHistoryRepository batteryRepo;
    private final SolarHistoryRepository solarRepo;
    private final GridHistoryRepository gridRepo;
    private final EnergyFlowService energyFlowService;

    public TelemetryConsumer(ObjectMapper objectMapper, SolarHistoryRepository solarRepo, GridHistoryRepository gridRepo, EnergyFlowService energyFlowService) {
        this.objectMapper = objectMapper;
        this.solarRepo = solarRepo;
        this.gridRepo = gridRepo;
        this.energyFlowService = energyFlowService;
    }


//    @KafkaListener(topics = {"battery-telemetry", "solar-telemetry", "grid-telemetry"}, groupId = "efs-consumer-group")
    @KafkaListener(topics = "#{'${kafka.topics}'.split(',')}", groupId = "${kafka.group-id}")
    public void consumeSimulationData(String message) {

        try {
            JsonNode node = objectMapper.readTree(message);

            // BATTERY telemetry
            if (node.has("batteryId")) {
                String id = node.get("batteryId").asText();
                double soc = node.get("soc").asDouble();
                double soh = node.get("soh").asDouble();
                double temp = node.get("temperature").asDouble();

                energyFlowService.processBatteryTelemetry(id, soc, soh, temp);

                return;
            }

            // SOLAR
            if (node.has("solarId")) {
                SolarHistory solar = SolarHistory.builder()
                        .solarId(node.get("solarId").asText())
                        .generation(node.get("generation").asDouble())
                        .status(node.has("status") ? node.get("status").asText() : "unknown")
                        .timestamp(LocalDateTime.now())
                        .build();

                solarRepo.save(solar);
                System.out.println("Solar data saved");
                return;
            }

            // GRID
            if (node.has("gridId")) {
                GridHistory grid = GridHistory.builder()
                        .gridId(node.get("gridId").asText())
                        .output(node.get("output").asDouble())
                        .timestamp(LocalDateTime.now())
                        .build();

                gridRepo.save(grid);
                System.out.println("Grid data saved: " + grid.getGridId() + ", output: " + grid.getOutput());
                return;
            }

        } catch (Exception e) {
            System.err.println("Error processing telemetry: " + e.getMessage());
        }
    }
}
