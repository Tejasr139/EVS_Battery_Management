package com.energy.efs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnergyFlowServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnergyFlowServiceApplication.class, args);
		System.out.println("Energy Flow Service Started...");
	}

}
