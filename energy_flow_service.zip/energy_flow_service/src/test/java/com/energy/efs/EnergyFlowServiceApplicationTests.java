package com.energy.efs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnergyFlowServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
