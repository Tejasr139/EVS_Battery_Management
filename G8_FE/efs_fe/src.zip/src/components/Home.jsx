import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const navigate = useNavigate();
  const [user] = useState(() => {
    const savedUser = localStorage.getItem('user');
    return savedUser ? JSON.parse(savedUser) : { name: 'Guest', role: 'user' };
  });
  const [batteriesData, setBatteriesData] = useState({});
  const [loading, setLoading] = useState(true);

  const handleLogout = () => {
    localStorage.removeItem('user');
    navigate('/login');
  };

  const handleBatteryClick = (batteryId) => {
    navigate(`/battery/${batteryId}`);
  };

  const getBatteryIcon = (soc) => {
    if (soc >= 80) return 'fas fa-battery-full';
    if (soc >= 60) return 'fas fa-battery-three-quarters';
    if (soc >= 40) return 'fas fa-battery-half';
    if (soc >= 20) return 'fas fa-battery-quarter';
    return 'fas fa-battery-empty';
  };

  const getBatteryColor = (soc) => {
    if (soc >= 80) return 'success';
    if (soc >= 40) return 'warning';
    return 'danger';
  };

  const fetchBatteriesData = async () => {
    try {
      const response = await fetch('http://localhost:8081/api/battery/all');
      if (response.ok) {
        const data = await response.json();
        const batteryMap = {};
        
        ['BATT-000', 'BATT-001', 'BATT-002'].forEach(batteryId => {
          const batteryRecords = data.filter(item => item.batteryId === batteryId);
          if (batteryRecords.length > 0) {
            const latest = batteryRecords.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))[0];
            batteryMap[batteryId] = latest;
          }
        });
        
        setBatteriesData(batteryMap);
      }
    } catch (error) {
      console.error('Error fetching batteries data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBatteriesData();
    const interval = setInterval(fetchBatteriesData, 60000); // Refresh every minute
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="d-flex" style={{minHeight: '100vh'}}>
      {/* Sidebar */}
      <div className="bg-dark text-white" style={{width: '250px', minHeight: '100vh'}}>
        <div className="p-3">
          <h4 className="mb-4">📊 Dashboard</h4>
          <nav>
            <ul className="list-unstyled">
              <li className="mb-2">
                <a href="#" className="text-white text-decoration-none d-flex align-items-center p-2 rounded hover-bg-secondary">
                  <i className="fas fa-home me-2"></i> Home
                </a>
              </li>
              <li className="mb-2">
                <a href="#" className="text-white text-decoration-none d-flex align-items-center p-2 rounded hover-bg-secondary">
                  <i className="fas fa-toggle-on me-2"></i> Feature Meters
                </a>
              </li>
              <li className="mb-2">
                <a href="#" className="text-white text-decoration-none d-flex align-items-center p-2 rounded hover-bg-secondary">
                  <i className="fas fa-users me-2"></i> Users
                </a>
              </li>
              <li className="mb-2">
                <a href="#" className="text-white text-decoration-none d-flex align-items-center p-2 rounded hover-bg-secondary">
                  <i className="fas fa-chart-bar me-2"></i> Analytics
                </a>
              </li>
              <li className="mb-2">
                <a href="#" className="text-white text-decoration-none d-flex align-items-center p-2 rounded hover-bg-secondary">
                  <i className="fas fa-cog me-2"></i> Settings
                </a>
              </li>
            </ul>
          </nav>
        </div>

      </div>

      {/* Main Content */}
      <div className="flex-grow-1">
        <header className="bg-light border-bottom p-3 d-flex justify-content-between align-items-center">
          <h2 className="mb-0">Welcome "{user.name}"</h2>
          <div className="dropdown">
            <button className="btn btn-link text-dark" type="button" data-bs-toggle="dropdown">
              <i className="fas fa-user-circle fs-3"></i>
            </button>
            <ul className="dropdown-menu dropdown-menu-end">
              <li><span className="dropdown-item-text fw-bold">{user.name}</span></li>
              <li><span className="dropdown-item-text text-muted">{user.role}</span></li>
              <li><hr className="dropdown-divider" /></li>
              <li><button className="dropdown-item" onClick={handleLogout}>
                <i className="fas fa-sign-out-alt me-2"></i>Logout
              </button></li>
            </ul>
          </div>
        </header>
        
        <main className="p-4">
          <h3 className="mb-4">Battery Management System</h3>
          {loading ? (
            <div className="d-flex justify-content-center">
              <div className="spinner-border" role="status">
                <span className="visually-hidden">Loading...</span>
              </div>
            </div>
          ) : (
            <div className="row g-4 justify-content-center">
              {['BATT-000', 'BATT-001', 'BATT-002'].map(batteryId => {
                const battery = batteriesData[batteryId];
                const soc = battery ? Math.round(battery.soc) : 0;
                const color = getBatteryColor(soc);
                const icon = getBatteryIcon(soc);
                const status = battery ? (battery.charging ? 'Charging' : 'Active') : 'Offline';
                const lastUpdate = battery ? new Date(battery.timestamp).toLocaleTimeString() : 'N/A';
                
                return (
                  <div key={batteryId} className="col-md-4">
                    <div className="card h-100 shadow-sm" style={{cursor: 'pointer'}} onClick={() => handleBatteryClick(batteryId)}>
                      <div className="card-body text-center">
                        <div className="mb-3">
                          <i className={`${icon} text-${color}`} style={{fontSize: '4rem'}}></i>
                        </div>
                        <h5 className="card-title">Battery {batteryId}</h5>
                        <p className="card-text">Status: {status}</p>
                        <div className={`badge bg-${color} mb-2`}>{soc}% Charged</div>
                        <div className="text-muted small">Last Updated: {lastUpdate}</div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default Home;