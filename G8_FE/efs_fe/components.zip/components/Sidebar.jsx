import { useNavigate, useLocation } from 'react-router-dom';
import { useSession } from '../contexts/SessionContext';
import '../styles/Sidebar.css';

const Sidebar = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useSession();

  const baseMenuItems = [
    { icon: '🏠', label: 'Home', path: '/home' },
    { icon: '📊', label: 'Battery Data', path: '/battery-data' },
    { icon: '📈', label: 'Analytics', path: '/analytics' }
  ];

  const adminMenuItems = [
    { icon: '👥', label: 'User Management', path: '/admin/users' },
    { icon: '⚙️', label: 'System Settings', path: '/admin/settings' },
    { icon: '📋', label: 'System Logs', path: '/admin/logs' }
  ];

  console.log('Sidebar - User:', user);
  console.log('Sidebar - User Role:', user?.role);
  
  const menuItems = user?.role === 'ADMIN' ? [...baseMenuItems, ...adminMenuItems] : baseMenuItems;
  
  console.log('Sidebar - Menu Items:', menuItems);

  const handleNavigation = (path) => {
    navigate(path);
  };

  return (
    <aside className="sidebar">
      <header className="sidebar-header">
        <section className="sidebar-logo">
          <span style={{fontSize: '1.5rem'}}>⚡</span>
          <span>EFS Manager</span>
        </section>
      </header>
      
      <nav className="sidebar-nav">
        <section className="nav-list">
          {menuItems.map((item, index) => (
            <article key={index} className="nav-item">
              <button 
                className={`nav-link ${location.pathname === item.path ? 'active' : ''}`}
                onClick={() => handleNavigation(item.path)}
              >
                <span style={{fontSize: '1.2rem'}}>{item.icon}</span>
                <span>{item.label}</span>
                <section className="nav-indicator"></section>
              </button>
            </article>
          ))}
        </section>
      </nav>
      
      <footer className="sidebar-footer">
        <section className="user-profile">
          <figure className="user-avatar">
            <span style={{fontSize: '1.2rem'}}>👤</span>
          </figure>
          <section className="user-info">
            <span className="user-name">{user?.name || 'User'}</span>
            <span className="user-role">{user?.role || 'USER'}</span>
          </section>
        </section>
      </footer>
    </aside>
  );
};

export default Sidebar;