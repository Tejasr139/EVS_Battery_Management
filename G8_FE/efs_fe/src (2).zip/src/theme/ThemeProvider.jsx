import React, { useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { setTheme, toggleTheme } from '../redux/slices/themeSlice';

export const ThemeContext = React.createContext({ toggle: () => {} });

const ThemeProvider = ({ children }) => {
  const mode = useSelector((s) => s.theme.mode);
  const dispatch = useDispatch();

  useEffect(() => {
    document.documentElement.classList.toggle('dark-theme', mode === 'dark');
    document.documentElement.classList.toggle('light-theme', mode === 'light');
  }, [mode]);

  return (
    <ThemeContext.Provider value={{ mode, toggle: () => dispatch(toggleTheme()) }}>
      {children}
    </ThemeContext.Provider>
  );
};

export default ThemeProvider;
