import axios from 'axios';
import store from '../redux/store';

const api = axios.create({
  baseURL: '',
  timeout: 10000,
});

// Request interceptor to add token if needed
api.interceptors.request.use((config) => {
  const state = store.getState();
  const token = state.user?.token;
  if (token) config.headers['Authorization'] = `Bearer ${token}`;
  return config;
}, (err) => Promise.reject(err));

// Response interceptor for global error handling (optional)
api.interceptors.response.use((res) => res, (err) => {
  // You can dispatch global actions for auth/refresh here
  return Promise.reject(err);
});

export default api;