const STORAGE_KEY = 'bms_app_v1';

export const loadState = () => {
  try {
    const serialized = localStorage.getItem(STORAGE_KEY);
    if (!serialized) return undefined;
    return JSON.parse(serialized);
  } catch (e) {
    console.warn('Failed to load state', e);
    return undefined;
  }
};

export const saveState = (state) => {
  try {
    // Only save slices we want persisted
    const toSave = {
      user: state.user,
      meters: state.meters,
      theme: state.theme,
      language: state.language,
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(toSave));
  } catch (e) {
    console.warn('Failed to save state', e);
  }
};