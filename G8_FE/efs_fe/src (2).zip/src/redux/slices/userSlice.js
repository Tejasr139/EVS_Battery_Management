import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../api/api';

// login thunk (calls your backend)
export const login = createAsyncThunk('user/login', async (credentials, { rejectWithValue }) => {
  try {
    const res = await api.post('http://localhost:8084/api/auth/login', credentials);
    // adapt depending on backend; here we expect success status
    // If backend gives token, include it.
    // Backend returns plain text in original code; we'll create a user object
    const token = res.data?.token || null;
    const user = {
      name: credentials.email.split('@')[0],
      email: credentials.email,
      role: credentials.email.includes('@admin') ? 'ADMIN' : 'USER',
      token,
    };
    return user;
  } catch (err) {
    const msg = err.response?.data || err.message || 'Login failed';
    return rejectWithValue(msg);
  }
});

export const register = createAsyncThunk('user/register', async (payload, { rejectWithValue }) => {
  try {
    const res = await api.post('http://localhost:8084/api/auth/register', payload);
    return { success: true };
  } catch (err) {
    const msg = err.response?.data || err.message || 'Registration failed';
    return rejectWithValue(msg);
  }
});

const initialState = {
  isAuthenticated: false,
  isAdmin: false,
  name: null,
  email: null,
  token: null,
  loading: false,
  error: null,
};

const slice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    logout: (state) => {
      state.isAuthenticated = false;
      state.isAdmin = false;
      state.name = null;
      state.email = null;
      state.token = null;
      state.error = null;
    },
    setUserFromStorage: (state, action) => {
      const u = action.payload;
      if (!u) return;
      state.isAuthenticated = true;
      state.isAdmin = u.role === 'ADMIN' || u.role === 'admin';
      state.name = u.name;
      state.email = u.email;
      state.token = u.token || null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(login.pending, (s) => { s.loading = true; s.error = null; })
      .addCase(login.fulfilled, (s, a) => {
        s.loading = false;
        s.isAuthenticated = true;
        s.name = a.payload.name;
        s.email = a.payload.email;
        s.token = a.payload.token || null;
        s.isAdmin = a.payload.role === 'ADMIN';
      })
      .addCase(login.rejected, (s, a) => { s.loading = false; s.error = a.payload || a.error.message; })

      .addCase(register.pending, (s) => { s.loading = true; s.error = null; })
      .addCase(register.fulfilled, (s) => { s.loading = false; })
      .addCase(register.rejected, (s, a) => { s.loading = false; s.error = a.payload || a.error.message; });
  }
});

export const { logout, setUserFromStorage } = slice.actions;
export default slice.reducer;
