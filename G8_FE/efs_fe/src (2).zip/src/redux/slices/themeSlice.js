import { createSlice } from '@reduxjs/toolkit';

const initial = {
  mode: 'light', // or 'dark'
};

const slice = createSlice({
  name: 'theme',
  initialState: initial,
  reducers: {
    toggleTheme: (state) => {
      state.mode = state.mode === 'light' ? 'dark' : 'light';
    },
    setTheme: (state, action) => {
      state.mode = action.payload;
    },
  }
});

export const { toggleTheme, setTheme } = slice.actions;
export default slice.reducer;