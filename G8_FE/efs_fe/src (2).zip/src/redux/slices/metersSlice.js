import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../api/api';

// fetch all meter/battery records
export const fetchAllBatteries = createAsyncThunk('meters/fetchAll', async (_, { rejectWithValue }) => {
  try {
    const res = await api.get('http://localhost:8081/api/battery/all');
    return res.data;
  } catch (err) {
    return rejectWithValue(err.response?.data || err.message || 'Failed to fetch batteries');
  }
});

const slice = createSlice({
  name: 'meters',
  initialState: {
    list: {}, // keyed by batteryId -> latest record
    raw: [], // raw records
    loading: false,
    error: null,
    lastUpdated: null,
  },
  reducers: {
    clearMeters: (state) => {
      state.list = {};
      state.raw = [];
      state.lastUpdated = null;
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchAllBatteries.pending, (s) => { s.loading = true; s.error = null; })
      .addCase(fetchAllBatteries.fulfilled, (s, a) => {
        s.loading = false;
        s.raw = a.payload;
        // build map of latest by batteryId
        const map = {};
        a.payload.forEach(item => {
          const existing = map[item.batteryId];
          if (!existing || new Date(item.timestamp) > new Date(existing.timestamp)) map[item.batteryId] = item;
        });
        s.list = map;
        s.lastUpdated = Date.now();
      })
      .addCase(fetchAllBatteries.rejected, (s, a) => {
        s.loading = false;
        s.error = a.payload || a.error.message;
      });
  }
});

export const { clearMeters } = slice.actions;
export default slice.reducer;
