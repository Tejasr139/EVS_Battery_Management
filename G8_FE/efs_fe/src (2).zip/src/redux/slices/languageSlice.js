import { createSlice } from '@reduxjs/toolkit';

const slice = createSlice({
  name: 'language',
  initialState: { code: 'en' },
  reducers: {
    setLanguage: (state, action) => {
      state.code = action.payload;
    },
  },
});

export const { setLanguage } = slice.actions;
export default slice.reducer;
