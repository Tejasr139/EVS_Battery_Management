import { configureStore } from '@reduxjs/toolkit';
import { loadState } from './persist';
import userReducer from './slices/userSlice';
import metersReducer from './slices/metersSlice';
import themeReducer from './slices/themeSlice';
import languageReducer from './slices/languageSlice';

const preloaded = loadState();

const store = configureStore({
  reducer: {
    user: userReducer,
    meters: metersReducer,
    theme: themeReducer,
    language: languageReducer,
  },
  preloadedState: preloaded,
  middleware: (getDefault) => getDefault(),
});

export default store;