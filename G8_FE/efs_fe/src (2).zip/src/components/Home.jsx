import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchAllBatteries } from '../redux/slices/metersSlice';
import { useNavigate } from 'react-router-dom';
import { logout } from '../redux/slices/userSlice';
import { useTranslation } from 'react-i18next';
import ThemeSwitch from './ThemeSwitch';

const Home = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { t } = useTranslation();

  const { list, loading, error } = useSelector(s => s.meters);
  const user = useSelector(s => s.user);
  const theme = useSelector(s => s.theme.mode);

  useEffect(() => {
    dispatch(fetchAllBatteries());
    const interval = setInterval(() => dispatch(fetchAllBatteries()), 60000);
    return () => clearInterval(interval);
  }, [dispatch]);

  const batteries = ['BATT-000','BATT-001','BATT-002'];

  const handleClick = (id) => navigate(`/battery/${id}`);
  const handleLogout = () => { dispatch(logout()); navigate('/login'); };

  const getBatteryIcon = (soc) => {
    if (soc >= 80) return 'fas fa-battery-full';
    if (soc >= 60) return 'fas fa-battery-three-quarters';
    if (soc >= 40) return 'fas fa-battery-half';
    if (soc >= 20) return 'fas fa-battery-quarter';
    return 'fas fa-battery-empty';
  };

  const getBatteryColor = (soc) => {
    if (soc >= 80) return 'success';
    if (soc >= 40) return 'warning';
    return 'danger';
  };

  return (
    <div className="d-flex" style={{minHeight: '100vh'}}>
      <div className="bg-dark text-white" style={{width: '250px', minHeight: '100vh'}}>
        <div className="p-3">
          <h4 className="mb-4">📊 Dashboard</h4>
          <nav>
            <ul className="list-unstyled">
              <li className="mb-2">
                <button onClick={() => navigate('/home')} className="btn text-white d-flex align-items-center p-2 rounded w-100 text-start">
                  <i className="fas fa-home me-2"></i> Home
                </button>
              </li>
              <li className="mb-2">
                <button className="btn text-white d-flex align-items-center p-2 rounded w-100 text-start" onClick={() => navigate('/admin')}>
                  <i className="fas fa-user-shield me-2"></i> Admin
                </button>
              </li>
            </ul>
          </nav>
        </div>
      </div>

      <div className="flex-grow-1">
        <header className="bg-light border-bottom p-3 d-flex justify-content-between align-items-center">
          <h2 className="mb-0">{t('welcome')} "{user.name || 'Guest'}"</h2>
          <div className="d-flex align-items-center gap-3">
            <div className="btn-group me-2">
              <ThemeSwitch />
              <button className="btn btn-outline-secondary" onClick={() => dispatch({ type: 'language/setLanguage', payload: 'en' })}>EN</button>
              <button className="btn btn-outline-secondary" onClick={() => dispatch({ type: 'language/setLanguage', payload: 'fr' })}>FR</button>
            </div>

            <div className="dropdown">
              <button className="btn btn-link text-dark" type="button" data-bs-toggle="dropdown">
                <i className="fas fa-user-circle fs-3"></i>
              </button>
              <ul className="dropdown-menu dropdown-menu-end">
                <li><span className="dropdown-item-text fw-bold">{user.name}</span></li>
                <li><span className="dropdown-item-text text-muted">{user.email}</span></li>
                <li><hr className="dropdown-divider" /></li>
                <li><button className="dropdown-item" onClick={handleLogout}><i className="fas fa-sign-out-alt me-2"></i>Logout</button></li>
              </ul>
            </div>
          </div>
        </header>

        <main className="p-4">
          <h3 className="mb-4">Battery Management System</h3>

          {loading && <div className="d-flex justify-content-center"><div className="spinner-border" role="status" /></div>}
          {error && <div className="alert alert-danger">{error}</div>}

          <div className="row g-4 justify-content-center">
            {batteries.map(batteryId => {
              const rec = list[batteryId];
              const soc = rec ? Math.round(rec.soc) : 0;
              const color = getBatteryColor(soc);
              const icon = getBatteryIcon(soc);
              const status = rec ? (rec.is_charging ? 'Charging' : 'Active') : 'Offline';
              const lastUpdate = rec ? new Date(rec.timestamp).toLocaleTimeString() : 'N/A';
              return (
                <div key={batteryId} className="col-md-4">
                  <div className="card h-100 shadow-sm" style={{cursor: 'pointer'}} onClick={() => handleClick(batteryId)}>
                    <div className="card-body text-center">
                      <div className="mb-3">
                        <i className={`${icon} text-${color}`} style={{fontSize: '4rem'}}></i>
                      </div>
                      <h5 className="card-title">Battery {batteryId}</h5>
                      <p className="card-text">Status: {status}</p>
                      <div className={`badge bg-${color} mb-2`}>{soc}% Charged</div>
                      <div className="text-muted small">Last Updated: {lastUpdate}</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </main>
      </div>
    </div>
  );
};

export default Home;
