import { useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { fetchAllBatteries } from '../redux/slices/metersSlice';
import api from '../api/api';

const BatteryDetails = () => {
  const { batteryId } = useParams();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const canvasRef = useRef(null);

  const { list, raw, loading } = useSelector(s => s.meters);
  const batteryData = list[batteryId] || null;
  const recentReadings = raw.filter(r => r.batteryId === batteryId)
    .sort((a,b) => new Date(b.timestamp)-new Date(a.timestamp)).slice(0,5);

  useEffect(() => {
    dispatch(fetchAllBatteries());
    const interval = setInterval(() => dispatch(fetchAllBatteries()), 300000);
    return () => clearInterval(interval);
  }, [dispatch]);

  useEffect(() => {
    drawChart(recentReadings.slice().reverse());
  }, [recentReadings]);

  const roundValue = (v) => Math.round(v*10)/10;

  const drawChart = (data) => {
    const canvas = canvasRef.current;
    if (!canvas || !data || data.length === 0) return;
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;
    ctx.clearRect(0,0,width,height);

    const padding = 40;
    const chartWidth = width - 2*padding;
    const chartHeight = height - 2*padding;

    const socValues = data.map(d=>d.soc);
    const minSoc = Math.min(...socValues) - 5;
    const maxSoc = Math.max(...socValues) + 5;

    ctx.strokeStyle = '#e0e0e0';
    ctx.lineWidth = 1;
    for (let i=0;i<=5;i++){
      const y = padding + (i * chartHeight / 5);
      ctx.beginPath();
      ctx.moveTo(padding, y);
      ctx.lineTo(width - padding, y);
      ctx.stroke();
    }

    ctx.strokeStyle = '#333';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(padding, padding);
    ctx.lineTo(padding, height - padding);
    ctx.lineTo(width - padding, height - padding);
    ctx.stroke();

    if (data.length > 1){
      ctx.strokeStyle = '#007bff';
      ctx.lineWidth = 3;
      ctx.beginPath();
      data.forEach((point, index) => {
        const x = padding + (index * chartWidth / (data.length - 1));
        const y = height - padding - ((point.soc - minSoc) / (maxSoc - minSoc)) * chartHeight;
        if (index === 0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
      });
      ctx.stroke();

      ctx.fillStyle = '#007bff';
      data.forEach((point, index) => {
        const x = padding + (index * chartWidth / (data.length - 1));
        const y = height - padding - ((point.soc - minSoc) / (maxSoc - minSoc)) * chartHeight;
        ctx.beginPath();
        ctx.arc(x,y,4,0,2*Math.PI);
        ctx.fill();
      });
    }

    ctx.fillStyle = '#333';
    ctx.font = '12px Arial';
    ctx.textAlign = 'right';
    for (let i=0;i<=5;i++){
      const value = Math.round(maxSoc - (i * (maxSoc - minSoc) / 5));
      const y = padding + (i * chartHeight / 5) + 4;
      ctx.fillText(value + '%', padding - 10, y);
    }

    ctx.textAlign = 'center';
    ctx.font = '14px Arial';
    ctx.fillText('SOC Over Time', width / 2, 20);
  };

  const handleCharge = async (target) => {
  try {
    const url = `http://localhost:8083/efs/control/charge/${target}?batteryId=${batteryId}&currentSoc=${target}`;
    await fetch(url, { method: 'POST' });
    alert(`Charge to ${target}% initiated`);
    dispatch(fetchAllBatteries());
  } catch (err) {
    console.error(err);
    alert('Failed to send charge command');
  }
};


  if (loading) return <div className="d-flex justify-content-center align-items-center" style={{minHeight: '100vh'}}><div className="spinner-border" /></div>;
  if (!batteryData) return <div className="d-flex justify-content-center align-items-center" style={{minHeight: '100vh'}}><div className="alert alert-warning">Battery data not found</div></div>;

  return (
    <div className="d-flex" style={{minHeight: '100vh'}}>
      {/* sidebar kept similar to your original */}
      <div className="bg-dark text-white" style={{width: '250px', minHeight: '100vh'}}>
        <div className="p-3">
          <h4 className="mb-4">📊 Dashboard</h4>
          <nav>
            <ul className="list-unstyled">
              <li className="mb-2">
                <button onClick={() => navigate('/home')} className="btn text-white text-decoration-none d-flex align-items-center p-2 rounded w-100 text-start">
                  <i className="fas fa-home me-2"></i> Home
                </button>
              </li>
            </ul>
          </nav>
        </div>
      </div>

      <div className="flex-grow-1">
        <header className="bg-light border-bottom p-3 d-flex justify-content-between align-items-center">
          <h2 className="mb-0">Battery {batteryId} Details</h2>
        </header>

        <main className="p-4">
          <div className="row g-4 mb-4">
            <div className="col-md-3"><div className="card text-center"><div className="card-body"><h5 className="card-title">SOC</h5><h2 className="text-primary">{roundValue(batteryData.soc)}%</h2></div></div></div>
            <div className="col-md-3"><div className="card text-center"><div className="card-body"><h5 className="card-title">SOH</h5><h2 className="text-success">{roundValue(batteryData.soh)}%</h2></div></div></div>
            <div className="col-md-3"><div className="card text-center"><div className="card-body"><h5 className="card-title">Temperature</h5><h2 className="text-danger">{roundValue(batteryData.temperature)}°C</h2></div></div></div>
            <div className="col-md-3"><div className="card text-center"><div className="card-body"><h5 className="card-title">Status</h5><h2 className={batteryData.is_charging ? "text-warning" : "text-info"}>{batteryData.is_charging ? "Charging" : "Idle"}</h2></div></div></div>
          </div>

          <div className="row mb-4">
            <div className="col-12">
              <div className="card">
                <div className="card-header"><h5 className="mb-0">🔋 Charge Control</h5></div>
                <div className="card-body">
                  <div className="d-flex gap-3 justify-content-center">
                    <button onClick={() => handleCharge(60)} className="btn btn-warning btn-lg px-4" style={{borderRadius:'10px'}}><i className="fas fa-bolt me-2"></i>Charge to 60%</button>
                    <button onClick={() => handleCharge(80)} className="btn btn-success btn-lg px-4" style={{borderRadius:'10px'}}><i className="fas fa-battery-three-quarters me-2"></i>Charge to 80%</button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="row g-4">
            <div className="col-md-8">
              <div className="card">
                <div className="card-header"><h5 className="mb-0">Battery Performance Chart</h5></div>
                <div className="card-body">
                  <canvas ref={canvasRef} width={600} height={300} style={{width: '100%', height:'auto', maxHeight:'300px'}} />
                </div>
              </div>
            </div>

            <div className="col-md-4">
              <div className="card">
                <div className="card-header"><h5 className="mb-0">Recent Readings</h5></div>
                <div className="card-body">
                  <table className="table table-sm">
                    <thead><tr><th>Time</th><th>Value</th></tr></thead>
                    <tbody>
                      {recentReadings.map((reading, idx) => (
                        <tr key={idx}><td>{new Date(reading.timestamp).toLocaleTimeString()}</td><td>{roundValue(reading.soc)}%</td></tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

          </div>
        </main>
      </div>
    </div>
  );
};

export default BatteryDetails;
