import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { register } from '../redux/slices/userSlice';
import { Link, useNavigate } from 'react-router-dom';

const Register = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { loading, error } = useSelector(s => s.user);

  const [formData, setFormData] = useState({
    firstName: '', lastName: '', email: '', phoneNumber: '', password: '', confirmPassword: '', gender: '', role: 'USER'
  });

  const handleChange = (e) => setFormData({...formData, [e.target.name]: e.target.value});

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (formData.password !== formData.confirmPassword) {
      alert('Passwords do not match');
      return;
    }
    const payload = {
      firstName: formData.firstName,
      lastName: formData.lastName,
      email: formData.email,
      phoneNumber: formData.phoneNumber,
      password: formData.password,
      gender: formData.gender,
      role: formData.role,
    };
    const action = await dispatch(register(payload));
    if (action.type === 'user/register/fulfilled') {
      alert('Registration successful!');
      navigate('/login');
    }
  };

  return (
    <div className="min-vh-100 d-flex align-items-center" style={{background: 'linear-gradient(135deg, #f093fb 0%, #f5576c 100%)'}}>
      <div className="container">
        <div className="row justify-content-center">
          <div className="col-md-8 col-lg-6">
            <div className="card shadow-lg border-0" style={{borderRadius: '15px'}}>
              <div className="card-body p-5">
                <div className="text-center mb-4">
                  <div className="bg-success rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style={{width: '60px', height: '60px'}}>
                    <i className="fas fa-user-plus text-white fs-4"></i>
                  </div>
                  <h2 className="fw-bold text-dark">Create Account</h2>
                  <p className="text-muted">Join us today and get started</p>
                </div>
                <form onSubmit={handleSubmit}>
                  {/* first/last */}
                  <div className="row">
                    <div className="col-md-6 mb-3">
                      <label className="form-label fw-semibold">First Name</label>
                      <input name="firstName" className="form-control" value={formData.firstName} onChange={handleChange} required/>
                    </div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label fw-semibold">Last Name</label>
                      <input name="lastName" className="form-control" value={formData.lastName} onChange={handleChange} required/>
                    </div>
                  </div>
                  {/* email/phone */}
                  <div className="row">
                    <div className="col-md-6 mb-3">
                      <label className="form-label fw-semibold">Email Address</label>
                      <input name="email" type="email" className="form-control" value={formData.email} onChange={handleChange} required/>
                    </div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label fw-semibold">Phone Number</label>
                      <input name="phoneNumber" className="form-control" value={formData.phoneNumber} onChange={handleChange} required/>
                    </div>
                  </div>
                  {/* passwords */}
                  <div className="row">
                    <div className="col-md-6 mb-3">
                      <label className="form-label fw-semibold">Password</label>
                      <input name="password" type="password" className="form-control" value={formData.password} onChange={handleChange} required/>
                    </div>
                    <div className="col-md-6 mb-3">
                      <label className="form-label fw-semibold">Confirm Password</label>
                      <input name="confirmPassword" type="password" className="form-control" value={formData.confirmPassword} onChange={handleChange} required/>
                    </div>
                  </div>
                  {/* gender/role */}
                  <div className="row">
                    <div className="col-md-6 mb-3">
                      <label className="form-label fw-semibold">Gender</label>
                      <select name="gender" className="form-select" value={formData.gender} onChange={handleChange} required>
                        <option value="">Select</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Other">Other</option>
                      </select>
                    </div>
                    <div className="col-md-6 mb-4">
                      <label className="form-label fw-semibold">Role</label>
                      <select name="role" className="form-select" value={formData.role} onChange={handleChange} required>
                        <option value="USER">User</option>
                        <option value="ADMIN">Admin</option>
                      </select>
                    </div>
                  </div>

                  <button type="submit" className="btn btn-success btn-lg w-100 mb-3" disabled={loading}>Create Account</button>
                </form>
                {error && <div className="alert alert-danger">{error}</div>}
                <div className="text-center">
                  <p className="mb-0">Already have an account? <Link to="/login" className="text-success fw-semibold">Sign In</Link></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> 
    </div>
  );
};

export default Register;
