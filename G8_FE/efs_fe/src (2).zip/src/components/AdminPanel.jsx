import React from 'react';
import AdminOnly from './AdminOnly';

const AdminPanel = () => {
  return (
    <AdminOnly>
      <div className="container p-4">
        <h2>Admin Panel</h2>
        <p>Only visible to admins.</p>
        {/* Add admin controls here */}
      </div>
    </AdminOnly>
  );
};

export default AdminPanel;
