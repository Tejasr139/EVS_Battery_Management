import React from 'react';
import { useSelector } from 'react-redux';
import { Navigate } from 'react-router-dom';

const ProtectedRoute = ({ children, adminOnly = false }) => {
  const user = useSelector((s) => s.user);
  if (!user.isAuthenticated) return <Navigate to="/login" replace />;
  if (adminOnly && !user.isAdmin) return <Navigate to="/home" replace />;
  return children;
};

export default ProtectedRoute;
