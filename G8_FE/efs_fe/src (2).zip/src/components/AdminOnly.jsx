import React from 'react';
import { useSelector } from 'react-redux';

const AdminOnly = ({ children }) => {
  const isAdmin = useSelector((s) => s.user.isAdmin);
  if (!isAdmin) return null;
  return <>{children}</>;
};

export default AdminOnly;