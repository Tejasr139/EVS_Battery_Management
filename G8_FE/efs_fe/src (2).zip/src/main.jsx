import React from 'react';
import { createRoot } from 'react-dom/client';
import 'bootstrap/dist/css/bootstrap.min.css';
import './index.css';
import App from './App';

import { Provider, useSelector } from 'react-redux';
import store from './redux/store';
import { saveState } from './redux/persist';

// persist store on changes
store.subscribe(() => {
  saveState(store.getState());
});

function ThemeWrapper() {
  const theme = useSelector((state) => state.theme.mode);

  // Apply theme to body
  document.body.className = theme;

  return <App />;
}

createRoot(document.getElementById('root')).render(
  <Provider store={store}>
    <ThemeWrapper />
  </Provider>
);
